DailyBell – Play Store graphic assets
=====================================

Upload in Play Console > Grow users > Store presence > Main store listing:

  play-store-icon-512.png        App icon        512 x 512 PNG (required)
  feature-graphic-1024x500.png   Feature graphic 1024 x 500 PNG, no alpha (required)

Also included:
  app-store-icon-1024.png        App Store icon for later (1024 x 1024, no alpha)
  android-launcher/              Launcher icons already applied in the app
                                 (adaptive + themed/monochrome + legacy + round)
  source/                        Editable SVG sources and a 1024 px master

Still needed for the listing (not graphics you can generate from the logo):
  - At least 2 phone screenshots (16:9 or 9:16, min side 320 px, max 3840 px)
  - Privacy policy URL (required because the app requests notification permission)

Suggested listing text
----------------------
App name (max 30):
  DailyBell – Timetable & Bells

Short description (max 80):
  Your daily timetable with a bell for every activity, like a school schedule.

Full description:
  DailyBell turns your day into a simple timetable that rings like a school bell.
  See what you should be doing right now, how much time is left, and what comes
  next, and get a bell when each activity starts.

  • Live dashboard: current activity, countdown, progress and up next
  • Full-day timeline with completed, current and upcoming activities
  • Bell reminders that ring even when the app is closed
  • Choose from three bell sounds, with optional vibration
  • Edit, add and remove activities in seconds
  • Light and dark themes
  • Works fully offline: no account, no ads, no tracking

  Tip: allow notifications and "Alarms & reminders" so bells ring on time.

Brand colours: #5B5BD6 (indigo), #FBBF24 (amber), white.
