DailyBell – Play Store listing assets
=====================================

Upload in Play Console > Grow users > Store presence > Main store listing > Graphics:

  File                                       Play field          Requirement (met)
  app-icon-512x512.png                       App icon            512 x 512 PNG, 32-bit, < 1 MB
  feature-graphic-1024x500.png               Feature graphic     1024 x 500 PNG, no alpha, < 15 MB
  phone-screenshots/01..06-*-1080x1920.png   Phone screenshots   9:16, 1080 x 1920, 2–8 images

Upload the screenshots in numbered order; the first 2–3 are what most people see.

  01 Live countdown          "Know what is on, every minute"
  02 Home-screen widget      "Your day on the home screen"
  03 Bell reminder           "A bell for every activity – rings 3 times, then stays quiet"
  04 Themes & dark mode      "Light, dark and 10 theme colours"
  05 Edit activities         "Edit your day in seconds"
  06 Reliable reminders      "Works offline. No account, no ads"

Also included:
  app-store-icon-1024x1024.png   App Store icon for later (no alpha, as Apple requires)
  source/                        SVG sources + the generator scripts used to build these

Tips for reach:
  - Keep the feature graphic as is: its text sits in the middle, away from edges Play may crop.
  - Tablet screenshots are optional; these phone shots are enough to publish.
  - Still needed before publishing: a privacy policy URL (the app asks for notification permission).

Suggested listing text
----------------------
App name (max 30):
  DailyBell – Timetable & Bells

Short description (max 80):
  Your daily timetable with a live countdown and a bell for every activity.

Full description:
  DailyBell turns your day into a simple timetable that rings like a school bell.
  See what you should be doing right now, how much time is left, and what comes
  next, and hear a short bell when each activity starts.

  • Live countdown: the current activity, time left and progress at a glance
  • Up next: always know what is coming and when
  • Gentle bell reminders: rings 3 times, then stays quiet, even when the app is closed
  • Home-screen widget: countdown, up next and your day's progress without opening the app
  • Full-day timeline with completed, current and upcoming activities
  • Edit, add and remove activities in seconds
  • Three bell sounds, optional vibration
  • 10 theme colours with light and dark mode
  • Works fully offline: no account, no ads, no tracking

  Tip: allow notifications and "Alarms & reminders" so bells ring on time.

Brand colours: #5B5BD6 (indigo), #FBBF24 (amber), white.
